from config import *
from models.banda import Banda

def criar_banda(data):
    banda = Banda(
        nome=data['nome'],
        pais=data['pais'],
        genero=data['genero'],
        qtalbuns=data['qtalbuns'],
        qtmembros=data.get('qtmembros')
    )
    
    # salvar no banco de dados
    db.session.add(banda)
    db.session.commit()
    
    return banda

def retornar_banda():
    # buscar todas as pessoas no 
    # banco de dados
    banda = Banda.query.all()
    
    return banda