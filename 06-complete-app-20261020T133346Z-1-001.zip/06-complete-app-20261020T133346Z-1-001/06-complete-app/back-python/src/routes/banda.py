from config import *
from models.banda import Banda
import services.banda as banda_service

@app.route('/banda', methods=['GET'])
def retornar_banda():

    banda = banda_service.retornar_banda()
    
    return jsonify({
        "resultado":"ok",
        "detalhes":[banda.json() for b in banda]
    })

@app.route('/criarbanda', methods=['POST'])
@jwt_required()  # exige que o usuário esteja autenticado para acessar esta rota
def criar_banda():
    # ler os dados em json
    dados = request.json
    
    # se faltou algum dado obrigatório...
    if not dados or not dados.get('nome') or not dados.get('pais') or not dados.get('genero') or not dados.get('qtalbuns') or not dados.get('qtmembros'):
        # retorna erro
        return jsonify({"resultado":"erro", "detalhes":"Nome, país, gênero, quantidade de álbuns e quantidade de membros são obrigatórios"}), 400
    
    # chama o serviço de criação de pessoa
    banda = banda_service.criar_banda(dados)    
    
    # retornar mensagem de sucesso :-)
    return jsonify({
        "resultado":"ok", 
        "detalhes":banda.json()
    }), 201

