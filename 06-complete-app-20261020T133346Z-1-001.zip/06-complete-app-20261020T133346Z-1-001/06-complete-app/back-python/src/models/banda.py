from config import *

class Banda(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(200), nullable=False)
    pais = db.Column(db.String(200), nullable=False)
    genero = db.Column(db.String(200), nullable=True)
    qtalbuns = db.Column(db.String(200), nullable=False)
    qtmembros = db.Column(db.String(200), nullable=False)

    def json(self):
        return {
            "id":self.id,
            "nome":self.nome,
            "pais":self.pais,
            "genero":self.genero,
            "qtalbuns":self.qtalbuns,
            "qtmembros":self.qtmembros
            }